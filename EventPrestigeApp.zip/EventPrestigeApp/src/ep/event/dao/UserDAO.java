/**
 * 
 */
package ep.event.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import ep.event.utils.BCrypt;

import ep.event.model.User;
import ep.event.utils.OracleQueries;
import ep.event.utils.Slugify;
import ep.event.utils.CreateFolder;
import ep.event.dao.OracleConnection;

/**
 * @author Jacob Nartey
 *
 */
public class UserDAO {
	
	//Workload value for BCrypt to generate random salt value for hashing
	private Slugify slug = new Slugify();
	private int strength = 12;
	
	//Get all the users
	public List<User> getAllUsers(){
		Connection conn = null;
		User user = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<User> list = new ArrayList<User>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETALLUSERS);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				user = new User();
				user.setUser_id(result.getInt(1));
				user.setSlug(result.getString(2));
				user.setFull_name(result.getString(3));
				user.setEmail(result.getString(4));
				user.setPassword(result.getString(5));
				user.setPhone(result.getString(6));
				user.setAddress(result.getString(7));
				user.setDob(result.getDate(8));
				user.setCountry(result.getString(9));
				user.setState(result.getString(10));
				user.setCity(result.getString(11));
				user.setImage(result.getString(12));
				user.setUser_role(result.getInt(13));
				user.setDate_created(result.getTimestamp(14));
				user.setDate_modified(result.getTimestamp(15));
				
				list.add(user);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	//Get user by id
	public User getUserByID(Integer user_id) throws SQLException{
		Connection conn = null;
		User user = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETUSERBYID);
			stmt.setInt(1, user_id);
			
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				user = new User();
				user.setUser_id(result.getInt(1));
				user.setSlug(result.getString(2));
				user.setFull_name(result.getString(3));
				user.setEmail(result.getString(4));
				user.setPassword(result.getString(5));
				user.setPhone(result.getString(6));
				user.setAddress(result.getString(7));
				user.setDob(result.getDate(8));
				user.setCountry(result.getString(9));
				user.setState(result.getString(10));
				user.setCity(result.getString(11));
				user.setImage(result.getString(12));
				user.setUser_role(result.getInt(13));
				user.setDate_created(result.getTimestamp(14));
				user.setDate_modified(result.getTimestamp(15));
			}
			
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return user;		
	}
	
	//Get user by slug
	public User getUserBySlug(String slug) throws SQLException{
		Connection conn = null;
		User user = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETUSERBYSLUG);
			stmt.setString(1, slug);
			
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				user = new User();
				user.setUser_id(result.getInt(1));
				user.setSlug(result.getString(2));
				user.setFull_name(result.getString(3));
				user.setEmail(result.getString(4));
				user.setPassword(result.getString(5));
				user.setPhone(result.getString(6));
				user.setAddress(result.getString(7));
				user.setDob(result.getDate(8));
				user.setCountry(result.getString(9));
				user.setState(result.getString(10));
				user.setCity(result.getString(11));
				user.setImage(result.getString(12));
				user.setUser_role(result.getInt(13));
				user.setDate_created(result.getTimestamp(14));
				user.setDate_modified(result.getTimestamp(15));
			}
			
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return user;		
	}
	
	//Get user by email
	public User getUserByEmail(String email) throws SQLException{
		Connection conn = null;
		User user = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETUSERBYEMAIL);
			stmt.setString(1, email);
			
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				user = new User();
				user.setUser_id(result.getInt(1));
				user.setSlug(result.getString(2));
				user.setFull_name(result.getString(3));
				user.setEmail(result.getString(4));
				user.setPassword(result.getString(5));
				user.setPhone(result.getString(6));
				user.setAddress(result.getString(7));
				user.setDob(result.getDate(8));
				user.setCountry(result.getString(9));
				user.setState(result.getString(10));
				user.setCity(result.getString(11));
				user.setImage(result.getString(12));
				user.setUser_role(result.getInt(13));
				user.setDate_created(result.getTimestamp(14));
				user.setDate_modified(result.getTimestamp(15));
			}
			
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return user;		
	}
	
	//Login returns User object
	public User login(String email, String password) throws SQLException {
		User user = null;
		Connection conn= null;
		PreparedStatement stmt = null;
		ResultSet result = null;
		
		try {
			conn= OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETUSERBYEMAIL);
			stmt.setString(1, email);
			result = stmt.executeQuery();
			
			if(result!= null && result.next()) {
				if(this.checkPassword(password, result.getString(5))) {
					user = new User();
					user.setUser_id(result.getInt(1));
					user.setSlug(result.getString(2));
					user.setFull_name(result.getString(3));
					user.setEmail(result.getString(4));
					user.setPassword(result.getString(5));
					user.setPhone(result.getString(6));
					user.setAddress(result.getString(7));
					user.setDob(result.getDate(8));
					user.setCountry(result.getString(9));
					user.setState(result.getString(10));
					user.setCity(result.getString(11));
					user.setImage(result.getString(12));
					user.setUser_role(result.getInt(13));
					user.setDate_created(result.getTimestamp(14));
					user.setDate_modified(result.getTimestamp(15));
				}
			}	
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return user;
	}
	
	//Validate login
	public boolean validateLogin(String email, String password) throws SQLException {
		Connection conn= null;
		PreparedStatement stmt = null;
		ResultSet result = null;
		boolean isValid = false;
		
		try {
			conn= OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETUSERBYEMAIL);
			stmt.setString(1, email);
			result = stmt.executeQuery();
			
			if(result!= null && result.next()) {
				if(this.checkPassword(password, result.getString(5))) {
					isValid = true;
				}
			}	
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return isValid;
	}
	
	//Add user to database
	public Integer registerUser(User user) {
		Integer ID = null;
		Connection conn = null;
		PreparedStatement stmt= null;
		ResultSet result = null;
		String [] COL = {"id"};
		CreateFolder folder = null;
		java.sql.Date sqlDOB = null;
		
		//Date currentDate = new Date();
		//Timestamp ts = new Timestamp(currentDate.getTime());
		//Date formatter
	    //SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-hh.mm.ss");

	    //String using the date format we want
	    //String folderName = formatter.format(currentDate);
		
		try {
			
			//Converting to date of birth to sql date
			if(!user.getDob().equals(null)) {
				sqlDOB = new java.sql.Date(user.getDob().getTime());
			}
			
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.SAVEUSER, COL);
			stmt.setString(1, slug.generateSlug(user.getEmail()));
			stmt.setString(2, user.getFull_name());
			stmt.setString(3, user.getEmail());
			stmt.setString(4, this.hashPassword(user.getPassword()));
			stmt.setString(5, user.getPhone());
			stmt.setString(6, user.getAddress());
			stmt.setDate(7, sqlDOB);
			stmt.setString(8, user.getCountry());
			stmt.setString(9, user.getState());
			stmt.setString(10, user.getCity());
			stmt.setString(11, user.getImage());
			stmt.setInt(12, user.getUser_role());
			stmt.setTimestamp(13, new Timestamp(System.currentTimeMillis()));
			stmt.setTimestamp(14, new Timestamp(System.currentTimeMillis()));
			
			stmt.executeUpdate();
			
			result = stmt.getGeneratedKeys();
			
			if(result!=null && result.next()) {
				ID = result.getInt(1);
				folder = new CreateFolder();
				folder.createFolder("src/uploads", user.getEmail());
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ID;
	}
	
	public Boolean updateUser(User user) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isUpdated = false;
		CreateFolder folder = null;
		java.sql.Date sqlDOB = null;
		
		try {
			String old_foldername = this.getUserByID(user.getUser_id()).getEmail();
			//Converting to date of birth to sql date
			if(!user.getDob().equals(null)) {
				sqlDOB = new java.sql.Date(user.getDob().getTime());
			}
			
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.UPDATEUSER);
			stmt.setString(1, slug.generateSlug(user.getEmail()));
			stmt.setString(2, user.getFull_name());
			stmt.setString(3, user.getEmail());
			stmt.setString(4, user.getPhone());
			stmt.setString(5, user.getAddress());
			stmt.setDate(6, sqlDOB);
			stmt.setString(7, user.getCountry());
			stmt.setString(8, user.getState());
			stmt.setString(9, user.getCity());
			stmt.setString(10, user.getImage());
			stmt.setTimestamp(11, new Timestamp(System.currentTimeMillis()));
			stmt.setInt(12, user.getUser_id());
			
			isUpdated = stmt.executeUpdate() > 0;
			
			if(isUpdated) {
				folder = new CreateFolder();
				folder.renameFolder("src/uploads", old_foldername, user.getEmail());
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isUpdated;
	}
	
	public Boolean updatePasswd(User user) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isUpdated = false;
		User queryUser = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.UPDATEUSERPASSWORD);
			
			queryUser = this.getUserByID(user.getUser_id());
			
			if(this.checkPassword(user.getPassword(), queryUser.getPassword())) {
				stmt.setString(1, this.hashPassword(user.getNew_password()));
				stmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
				stmt.setInt(3, user.getUser_id());
				isUpdated = stmt.executeUpdate() > 0;
			}
						
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isUpdated;
	}
	
	public Boolean deleteUser(Integer user_id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isDeleted = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.DELETEUSER);
			stmt.setInt(1, user_id);
			stmt.executeUpdate();
			isDeleted = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isDeleted;
	}
	
	//Hash password using bcrypt
	public String hashPassword(String password_plaintext) {
		String salt = BCrypt.gensalt(strength);
		String hashed_password = BCrypt.hashpw(password_plaintext, salt);

		return hashed_password;
	}
	
	//Check password
	public Boolean checkPassword(String password_plaintext, String stored_hash) {
		Boolean password_verified = false;

		if(stored_hash == null || !stored_hash.startsWith("$2a$"))
			throw new java.lang.IllegalArgumentException("Invalid hash provided");

		password_verified = BCrypt.checkpw(password_plaintext, stored_hash);

		return password_verified;
	}
}
