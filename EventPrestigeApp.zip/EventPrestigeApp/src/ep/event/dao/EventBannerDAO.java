/**
 * 
 */
package ep.event.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import ep.event.model.EventBanner;
import ep.event.utils.OracleQueries;
import ep.event.utils.Slugify;

/**
 * @author Jacob Nartey
 *
 */
public class EventBannerDAO {
	private Slugify slug = new Slugify();
	
	public List<EventBanner> getAllBanners() {
		Connection conn = null;
		EventBanner banner = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<EventBanner> list = new ArrayList<EventBanner>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETALLEVENTBANNERS);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				banner = new EventBanner();
				banner.setBanner_id(result.getInt(1));
				banner.setSlug(result.getString(2));
				banner.setEvent_id(result.getInt(3));
				banner.setTitle(result.getString(4));
				banner.setDescription(result.getString(5));
				banner.setImage(result.getString(6));
				banner.setDate_created(result.getTimestamp(7));
				banner.setDate_modified(result.getTimestamp(8));
				list.add(banner);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public EventBanner getBannerByID(Integer banner_id) {
		Connection conn = null;
		EventBanner banner = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETEVENTBANNERBYID);
			stmt.setInt(1, banner_id);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				banner = new EventBanner();
				banner.setBanner_id(result.getInt(1));
				banner.setSlug(result.getString(2));
				banner.setEvent_id(result.getInt(3));
				banner.setTitle(result.getString(4));
				banner.setDescription(result.getString(5));
				banner.setImage(result.getString(6));
				banner.setDate_created(result.getTimestamp(7));
				banner.setDate_modified(result.getTimestamp(8));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return banner;
	}
	
	public EventBanner getBannerBySlug(Integer slug) {
		Connection conn = null;
		EventBanner banner = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETEVENTBANNERBYSLUG);
			stmt.setInt(1, slug);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				banner = new EventBanner();
				banner.setBanner_id(result.getInt(1));
				banner.setSlug(result.getString(2));
				banner.setEvent_id(result.getInt(3));
				banner.setTitle(result.getString(4));
				banner.setDescription(result.getString(5));
				banner.setImage(result.getString(6));
				banner.setDate_created(result.getTimestamp(7));
				banner.setDate_modified(result.getTimestamp(8));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return banner;
	}
	
	public List<EventBanner> getAllBannersByEvent(Integer event_id) {
		Connection conn = null;
		EventBanner banner = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<EventBanner> list = new ArrayList<EventBanner>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETBANNERSBYEVENT);
			stmt.setInt(1, event_id);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				banner = new EventBanner();
				banner.setBanner_id(result.getInt(1));
				banner.setSlug(result.getString(2));
				banner.setEvent_id(result.getInt(3));
				banner.setTitle(result.getString(4));
				banner.setDescription(result.getString(5));
				banner.setImage(result.getString(6));
				banner.setDate_created(result.getTimestamp(7));
				banner.setDate_modified(result.getTimestamp(8));
				list.add(banner);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public Integer addBanner(EventBanner banner) throws SQLException {
		Integer ID = null;
		Connection conn = null;
		PreparedStatement stmt= null;
		ResultSet result = null;
		String [] COL = {"id"};
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.SAVEEVENTBANNER, COL);
			stmt.setString(1, slug.generateSlug(banner.getTitle()) + "-" + banner.getEvent_id());
			stmt.setInt(2, banner.getEvent_id());
			stmt.setString(3, banner.getTitle());
			stmt.setString(4, banner.getDescription());
			stmt.setString(5, banner.getImage());
			stmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
			stmt.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
			
			stmt.executeUpdate();
			
			result = stmt.getGeneratedKeys();
			
			if(result!=null && result.next()) {
				ID = result.getInt(1);
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return ID;
	}
	
	public Boolean updateBanner(EventBanner banner) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isUpdated = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.UPDATEEVENTBANNER);
			stmt.setString(1, slug.generateSlug(banner.getTitle()) + "-" + banner.getEvent_id());
			stmt.setString(2, banner.getTitle());
			stmt.setString(3, banner.getDescription());
			stmt.setString(4, banner.getImage());
			stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
			stmt.setInt(6, banner.getBanner_id());
			
			isUpdated = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isUpdated;
	}
	
	public Boolean deleteBanner(Integer banner_id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isDeleted = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.DELETEEVENTBANNER);
			stmt.setInt(1, banner_id);
			stmt.executeUpdate();
			isDeleted = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isDeleted;
	}
}
