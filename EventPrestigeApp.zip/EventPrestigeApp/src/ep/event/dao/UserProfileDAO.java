/**
 * 
 */
package ep.event.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import ep.event.model.UserProfile;
import ep.event.utils.OracleQueries;
import ep.event.utils.Slugify;

/**
 * @author Jacob Nartey
 *
 */
public class UserProfileDAO {
	private Slugify slug = new Slugify();
	
	public List<UserProfile> getAllUserProfiles() {
		Connection conn = null;
		UserProfile profile = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<UserProfile> list = new ArrayList<UserProfile>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETALLUSERPROFILES);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				profile = new UserProfile();
				profile.setUser_profile_id(result.getInt(1));
				profile.setSlug(result.getString(2));
				profile.setUser_id(result.getInt(3));
				profile.setTitle(result.getString(4));
				profile.setDescription(result.getString(5));
				profile.setImage(result.getString(6));
				profile.setDate_created(result.getTimestamp(7));
				profile.setDate_modified(result.getTimestamp(8));
				list.add(profile);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public List<UserProfile> getAllProfileByUser(Integer user_id) {
		Connection conn = null;
		UserProfile profile = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<UserProfile> list = new ArrayList<UserProfile>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETPROFILESBYUSER);
			stmt.setInt(1, user_id);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				profile = new UserProfile();
				profile.setUser_profile_id(result.getInt(1));
				profile.setSlug(result.getString(2));
				profile.setUser_id(result.getInt(3));
				profile.setTitle(result.getString(4));
				profile.setDescription(result.getString(5));
				profile.setImage(result.getString(6));
				profile.setDate_created(result.getTimestamp(7));
				profile.setDate_modified(result.getTimestamp(8));
				list.add(profile);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public UserProfile getUserProfileByID(Integer profile_id) {
		Connection conn = null;
		UserProfile profile = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETUSERPROFILEBYID);
			stmt.setInt(1, profile_id);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				profile = new UserProfile();
				profile.setUser_profile_id(result.getInt(1));
				profile.setSlug(result.getString(2));
				profile.setUser_id(result.getInt(3));
				profile.setTitle(result.getString(4));
				profile.setDescription(result.getString(5));
				profile.setImage(result.getString(6));
				profile.setDate_created(result.getTimestamp(7));
				profile.setDate_modified(result.getTimestamp(8));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return profile;
	}
	
	public UserProfile getUserProfileBySlug(Integer slug) {
		Connection conn = null;
		UserProfile profile = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETUSERPROFILEBYSLUG);
			stmt.setInt(1, slug);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				profile = new UserProfile();
				profile.setUser_profile_id(result.getInt(1));
				profile.setSlug(result.getString(2));
				profile.setUser_id(result.getInt(3));
				profile.setTitle(result.getString(4));
				profile.setDescription(result.getString(5));
				profile.setImage(result.getString(6));
				profile.setDate_created(result.getTimestamp(7));
				profile.setDate_modified(result.getTimestamp(8));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return profile;
	}
	
	public Integer addUserProfile(UserProfile profile) throws SQLException {
		Integer ID = null;
		Connection conn = null;
		PreparedStatement stmt= null;
		ResultSet result = null;
		String [] COL = {"id"};
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.SAVEUSERPROFILE, COL);
			stmt.setString(1, slug.generateSlug(profile.getTitle()) + "-" + profile.getUser_id());
			stmt.setInt(2, profile.getUser_id());
			stmt.setString(3, profile.getTitle());
			stmt.setString(4, profile.getDescription());
			stmt.setString(5, profile.getImage());
			stmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
			stmt.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
			
			stmt.executeUpdate();
			
			result = stmt.getGeneratedKeys();
			
			if(result!=null && result.next()) {
				ID = result.getInt(1);
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return ID;
	}
	
	public Boolean updateUserProfile(UserProfile profile) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isUpdated = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.UPDATEUSERPROFILE);
			stmt.setString(1, slug.generateSlug(profile.getTitle()) + "-" + profile.getUser_id());
			stmt.setString(2, profile.getTitle());
			stmt.setString(3, profile.getDescription());
			stmt.setString(4, profile.getImage());
			stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
			stmt.setInt(6, profile.getUser_profile_id());
			
			isUpdated = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isUpdated;
	}
	
	public Boolean deleteUserProfile(Integer profile_id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isDeleted = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.DELETEUSERPROFILE);
			stmt.setInt(1, profile_id);
			stmt.executeUpdate();
			isDeleted = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isDeleted;
	}
}
