/**
 * 
 */
package ep.event.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import ep.event.model.EventGallery;
import ep.event.utils.OracleQueries;
import ep.event.utils.Slugify;

/**
 * @author Jacob Nartey
 *
 */
public class EventGalleryDAO {
	private Slugify slug = new Slugify();
	
	public List<EventGallery> getAllEventGallery() {
		Connection conn = null;
		EventGallery gallery = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<EventGallery> list = new ArrayList<EventGallery>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETALLEVENTGALLERIES);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				gallery = new EventGallery();
				gallery.setEvent_gallery_id(result.getInt(1));
				gallery.setSlug(result.getString(2));
				gallery.setEvent_id(result.getInt(3));
				gallery.setTitle(result.getString(4));
				gallery.setDescription(result.getString(5));
				gallery.setDate_created(result.getTimestamp(6));
				gallery.setDate_modified(result.getTimestamp(7));
				
				list.add(gallery);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public EventGallery getGalleryByID(Integer gallery_id) {
		Connection conn = null;
		EventGallery gallery = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETGALLERYBYID);
			stmt.setInt(1, gallery_id);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				gallery = new EventGallery();
				gallery.setEvent_gallery_id(result.getInt(1));
				gallery.setSlug(result.getString(2));
				gallery.setEvent_id(result.getInt(3));
				gallery.setTitle(result.getString(4));
				gallery.setDescription(result.getString(5));
				gallery.setDate_created(result.getTimestamp(6));
				gallery.setDate_modified(result.getTimestamp(7));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return gallery;
	}
	
	public EventGallery getGalleryBySlug(Integer slug) {
		Connection conn = null;
		EventGallery gallery = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETGALLERYBYSLUG);
			stmt.setInt(1, slug);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				gallery = new EventGallery();
				gallery.setEvent_gallery_id(result.getInt(1));
				gallery.setSlug(result.getString(2));
				gallery.setEvent_id(result.getInt(3));
				gallery.setTitle(result.getString(4));
				gallery.setDescription(result.getString(5));
				gallery.setDate_created(result.getTimestamp(6));
				gallery.setDate_modified(result.getTimestamp(7));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return gallery;
	}
	
	public List<EventGallery> getGalleryByEvent(Integer event_id) {
		Connection conn = null;
		EventGallery gallery = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<EventGallery> list = new ArrayList<EventGallery>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETGALLERYBYEVENT);
			stmt.setInt(1, event_id);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				gallery = new EventGallery();
				gallery.setEvent_gallery_id(result.getInt(1));
				gallery.setSlug(result.getString(2));
				gallery.setEvent_id(result.getInt(3));
				gallery.setTitle(result.getString(4));
				gallery.setDescription(result.getString(5));
				gallery.setDate_created(result.getTimestamp(6));
				gallery.setDate_modified(result.getTimestamp(7));
				list.add(gallery);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public Integer addEventGallery(EventGallery gallery) throws SQLException {
		Integer ID = null;
		Connection conn = null;
		PreparedStatement stmt= null;
		ResultSet result = null;
		String [] COL = {"id"};
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.SAVEGALLERY, COL);
			stmt.setString(1, slug.generateSlug(gallery.getTitle()) + "-" + gallery.getEvent_id());
			stmt.setInt(2, gallery.getEvent_id());
			stmt.setString(3, gallery.getTitle());
			stmt.setString(4, gallery.getDescription());
			stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
			stmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
			
			stmt.executeUpdate();
			
			result = stmt.getGeneratedKeys();
			
			if(result!=null && result.next()) {
				ID = result.getInt(1);
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return ID;
	}
	
	public Boolean updateEventGallery(EventGallery gallery) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isUpdated = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.UPDATEGALLERY);
			stmt.setString(1, slug.generateSlug(gallery.getTitle()) + "-" + gallery.getEvent_id());
			stmt.setString(2, gallery.getTitle());
			stmt.setString(3, gallery.getDescription());
			stmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
			stmt.setInt(5, gallery.getEvent_gallery_id());
			
			isUpdated = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isUpdated;
	}
	
	public Boolean deleteEventGallery(Integer gallery_id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isDeleted = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.DELETEGALLERY);
			stmt.setInt(1, gallery_id);
			stmt.executeUpdate();
			isDeleted = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isDeleted;
	}
}
