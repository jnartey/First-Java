/**
 * 
 */
package ep.event.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import ep.event.model.EventWishlist;
import ep.event.utils.OracleQueries;
import ep.event.utils.Slugify;

/**
 * @author Jacob Nartey
 *
 */
public class EventWishlistDAO {
	private Slugify slug = new Slugify();
	
	public List<EventWishlist> getAllWishList(){
		Connection conn = null;
		EventWishlist wishlist = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<EventWishlist> list = new ArrayList<EventWishlist>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETALLEVENTWISHLISTS);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				wishlist = new EventWishlist();
				wishlist.setEvent_wishlist_id(result.getInt(1));
				wishlist.setSlug(result.getString(2));
				wishlist.setEvent_id(result.getInt(3));
				wishlist.setTitle(result.getString(4));
				wishlist.setDescription(result.getString(5));
				wishlist.setImage(result.getString(6));
				wishlist.setDate_created(result.getTimestamp(7));
				wishlist.setDate_modified(result.getTimestamp(8));
				list.add(wishlist);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public EventWishlist getWishListByID(Integer wishlish_id){
		Connection conn = null;
		EventWishlist wishlist = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETWISHLISTBYID);
			stmt.setInt(1, wishlish_id);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				wishlist = new EventWishlist();
				wishlist.setEvent_wishlist_id(result.getInt(1));
				wishlist.setSlug(result.getString(2));
				wishlist.setEvent_id(result.getInt(3));
				wishlist.setTitle(result.getString(4));
				wishlist.setDescription(result.getString(5));
				wishlist.setImage(result.getString(6));
				wishlist.setDate_created(result.getTimestamp(7));
				wishlist.setDate_modified(result.getTimestamp(8));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return wishlist;
	}
	
	public EventWishlist getWishListBySlug(Integer slug){
		Connection conn = null;
		EventWishlist wishlist = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETWISHLISTBYSLUG);
			stmt.setInt(1, slug);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				wishlist = new EventWishlist();
				wishlist.setEvent_wishlist_id(result.getInt(1));
				wishlist.setSlug(result.getString(2));
				wishlist.setEvent_id(result.getInt(3));
				wishlist.setTitle(result.getString(4));
				wishlist.setDescription(result.getString(5));
				wishlist.setImage(result.getString(6));
				wishlist.setDate_created(result.getTimestamp(7));
				wishlist.setDate_modified(result.getTimestamp(8));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return wishlist;
	}
	
	public List<EventWishlist> getAllWishListByEvent(Integer event_id){
		Connection conn = null;
		EventWishlist wishlist = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<EventWishlist> list = new ArrayList<EventWishlist>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETWISHLISTBYEVENT);
			stmt.setInt(1, event_id);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				wishlist = new EventWishlist();
				wishlist.setEvent_wishlist_id(result.getInt(1));
				wishlist.setSlug(result.getString(2));
				wishlist.setEvent_id(result.getInt(3));
				wishlist.setTitle(result.getString(4));
				wishlist.setDescription(result.getString(5));
				wishlist.setImage(result.getString(6));
				wishlist.setDate_created(result.getTimestamp(7));
				wishlist.setDate_modified(result.getTimestamp(8));
				list.add(wishlist);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public Integer addEventWishlist(EventWishlist wishlist) throws SQLException {
		Integer ID = null;
		Connection conn = null;
		PreparedStatement stmt= null;
		ResultSet result = null;
		String [] COL = {"id"};
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.SAVEWISHLIST, COL);
			stmt.setString(1, wishlist.getSlug());
			stmt.setInt(2, wishlist.getEvent_id());
			stmt.setString(3, wishlist.getTitle());
			stmt.setString(4, wishlist.getDescription());
			stmt.setString(5, wishlist.getImage());
			stmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
			stmt.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
			
			stmt.executeUpdate();
			
			result = stmt.getGeneratedKeys();
			
			if(result!=null && result.next()) {
				ID = result.getInt(1);
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return ID;
	}
	
	public Boolean updateEventWishlist(EventWishlist wishlist) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isUpdated = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.UPDATEWISHLIST);
			stmt.setString(1, slug.generateSlug(wishlist.getTitle()) + "-" + wishlist.getEvent_id());
			stmt.setString(2, wishlist.getTitle());
			stmt.setString(3, wishlist.getDescription());
			stmt.setString(4, wishlist.getImage());
			stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
			stmt.setInt(6, wishlist.getEvent_wishlist_id());
			
			isUpdated = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isUpdated;
	}
	
	public Boolean deleteEventWishlist(Integer wishlist_id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isDeleted = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.DELETEWISHLIST);
			stmt.setInt(1, wishlist_id);
			stmt.executeUpdate();
			isDeleted = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isDeleted;
	}
}
