/**
 * 
 */
package ep.event.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import ep.event.model.EventImage;
import ep.event.utils.OracleQueries;
import ep.event.utils.Slugify;

/**
 * @author Jacob Nartey
 *
 */
public class EventImageDAO {
	private Slugify slug = new Slugify();
	
	public List<EventImage> getAllEventImage() {
		Connection conn = null;
		EventImage image = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<EventImage> list = new ArrayList<EventImage>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETALLEVENTIMAGES);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				image = new EventImage();
				image.setEvent_image_id(result.getInt(1));
				image.setSlug(result.getString(2));
				image.setEvent_gallery_id(result.getInt(3));
				image.setTitle(result.getString(4));
				image.setImage(result.getString(5));
				image.setDate_created(result.getTimestamp(6));
				image.setDate_modified(result.getTimestamp(7));
				
				list.add(image);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public EventImage getImageByID(Integer image_id) {
		Connection conn = null;
		EventImage image = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETIMAGEBYID);
			stmt.setInt(1, image_id);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				image = new EventImage();
				image.setEvent_image_id(result.getInt(1));
				image.setSlug(result.getString(2));
				image.setEvent_gallery_id(result.getInt(3));
				image.setTitle(result.getString(4));
				image.setImage(result.getString(5));
				image.setDate_created(result.getTimestamp(6));
				image.setDate_modified(result.getTimestamp(7));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return image;
	}
	
	public EventImage getImageBySlug(Integer slug) {
		Connection conn = null;
		EventImage image = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETIMAGEBYSLUG);
			stmt.setInt(1, slug);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				image = new EventImage();
				image.setEvent_image_id(result.getInt(1));
				image.setSlug(result.getString(2));
				image.setEvent_gallery_id(result.getInt(3));
				image.setTitle(result.getString(4));
				image.setImage(result.getString(5));
				image.setDate_created(result.getTimestamp(6));
				image.setDate_modified(result.getTimestamp(7));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return image;
	}
	
	public List<EventImage> getAllEventImageByGallery(Integer event_gallery_id) {
		Connection conn = null;
		EventImage image = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<EventImage> list = new ArrayList<EventImage>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETIMAGEBYGALLERY);
			stmt.setInt(1, event_gallery_id);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				image = new EventImage();
				image.setEvent_image_id(result.getInt(1));
				image.setSlug(result.getString(2));
				image.setEvent_gallery_id(result.getInt(3));
				image.setTitle(result.getString(4));
				image.setImage(result.getString(5));
				image.setDate_created(result.getTimestamp(6));
				image.setDate_modified(result.getTimestamp(7));
				list.add(image);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public Integer addEventImage(EventImage image) throws SQLException {
		Integer ID = null;
		Connection conn = null;
		PreparedStatement stmt= null;
		ResultSet result = null;
		String [] COL = {"id"};
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.SAVEIMAGE, COL);
			stmt.setString(1, slug.generateSlug(image.getTitle()) + "-" + image.getEvent_gallery_id());
			stmt.setInt(2, image.getEvent_gallery_id());
			stmt.setString(3, image.getTitle());
			stmt.setString(4, image.getImage());
			stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
			stmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
			
			stmt.executeUpdate();
			
			result = stmt.getGeneratedKeys();
			
			if(result!=null && result.next()) {
				ID = result.getInt(1);
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return ID;
	}
	
	public Boolean updateEventImage(EventImage image) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isUpdated = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.UPDATEIMAGE);
			stmt.setString(1, slug.generateSlug(image.getTitle()) + "-" + image.getEvent_gallery_id());
			stmt.setString(2, image.getTitle());
			stmt.setString(3, image.getImage());
			stmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
			stmt.setInt(5, image.getEvent_image_id());
			
			isUpdated = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isUpdated;
	}
	
	public Boolean deleteEventImage(Integer image_id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isDeleted = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.DELETEIMAGE);
			stmt.setInt(1, image_id);
			stmt.executeUpdate();
			isDeleted = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isDeleted;
	}
}
