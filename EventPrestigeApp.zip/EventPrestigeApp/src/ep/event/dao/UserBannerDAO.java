/**
 * 
 */
package ep.event.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import ep.event.model.UserBanner;
import ep.event.utils.OracleQueries;
import ep.event.utils.Slugify;

/**
 * @author Jacob Nartey
 *
 */
public class UserBannerDAO {
	private Slugify slug = new Slugify();
	
	public List<UserBanner> getAllBanners() {
		Connection conn = null;
		UserBanner banner = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<UserBanner> list = new ArrayList<UserBanner>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETALLBANNERS);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				banner = new UserBanner();
				banner.setBanner_id(result.getInt(1));
				banner.setSlug(result.getString(2));
				banner.setUser_id(result.getInt(3));
				banner.setTitle(result.getString(4));
				banner.setDescription(result.getString(5));
				banner.setImage(result.getString(6));
				banner.setDate_created(result.getTimestamp(7));
				banner.setDate_modified(result.getTimestamp(8));
				list.add(banner);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public UserBanner getBannerByID(Integer banner_id) {
		Connection conn = null;
		UserBanner banner = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETBANNERBYID);
			stmt.setInt(1, banner_id);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				banner = new UserBanner();
				banner.setBanner_id(result.getInt(1));
				banner.setSlug(result.getString(2));
				banner.setUser_id(result.getInt(3));
				banner.setTitle(result.getString(4));
				banner.setDescription(result.getString(5));
				banner.setImage(result.getString(6));
				banner.setDate_created(result.getTimestamp(7));
				banner.setDate_modified(result.getTimestamp(8));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return banner;
	}
	
	public UserBanner getBannerBySlug(Integer slug) {
		Connection conn = null;
		UserBanner banner = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETBANNERBYSLUG);
			stmt.setInt(1, slug);
			result = stmt.executeQuery();
			
			if(result != null && result.next()) {
				banner = new UserBanner();
				banner.setBanner_id(result.getInt(1));
				banner.setSlug(result.getString(2));
				banner.setUser_id(result.getInt(3));
				banner.setTitle(result.getString(4));
				banner.setDescription(result.getString(5));
				banner.setImage(result.getString(6));
				banner.setDate_created(result.getTimestamp(7));
				banner.setDate_modified(result.getTimestamp(8));
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return banner;
	}
	
	public List<UserBanner> getAllBannersByUser(Integer user_id) {
		Connection conn = null;
		UserBanner banner = null;
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<UserBanner> list = new ArrayList<UserBanner>();
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.GETBANNERSBYUSER);
			stmt.setInt(1, user_id);
			result = stmt.executeQuery();
			
			while(result != null && result.next()) {
				banner = new UserBanner();
				banner.setBanner_id(result.getInt(1));
				banner.setSlug(result.getString(2));
				banner.setUser_id(result.getInt(3));
				banner.setTitle(result.getString(4));
				banner.setDescription(result.getString(5));
				banner.setImage(result.getString(6));
				banner.setDate_created(result.getTimestamp(7));
				banner.setDate_modified(result.getTimestamp(8));
				list.add(banner);
			}
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public Integer addBanner(UserBanner banner) throws SQLException {
		Integer ID = null;
		Connection conn = null;
		PreparedStatement stmt= null;
		ResultSet result = null;
		String [] COL = {"id"};
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.SAVEBANNER, COL);
			stmt.setString(1, slug.generateSlug(banner.getTitle()) + "-" + banner.getUser_id());
			stmt.setInt(2, banner.getUser_id());
			stmt.setString(3, banner.getTitle());
			stmt.setString(4, banner.getDescription());
			stmt.setString(5, banner.getImage());
			stmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
			stmt.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
			
			stmt.executeUpdate();
			
			result = stmt.getGeneratedKeys();
			
			if(result!=null && result.next()) {
				ID = result.getInt(1);
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			result.close();
			if(stmt!=null ) {
				stmt.close();
				
			}
			if(conn !=null) {
				conn.close();
			}
		}
		
		return ID;
	}
	
	public Boolean updateBanner(UserBanner banner) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isUpdated = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.UPDATEBANNER);
			stmt.setString(1, slug.generateSlug(banner.getTitle()) + "-" + banner.getUser_id());
			stmt.setString(2, banner.getTitle());
			stmt.setString(3, banner.getDescription());
			stmt.setString(4, banner.getImage());
			stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
			stmt.setInt(6, banner.getBanner_id());
			
			isUpdated = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isUpdated;
	}
	
	public Boolean deleteBanner(Integer banner_id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		Boolean isDeleted = false;
		
		try {
			conn = OracleConnection.getConnection();
			stmt = conn.prepareStatement(OracleQueries.DELETEBANNER);
			stmt.setInt(1, banner_id);
			stmt.executeUpdate();
			isDeleted = stmt.executeUpdate() > 0;
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isDeleted;
	}
}
