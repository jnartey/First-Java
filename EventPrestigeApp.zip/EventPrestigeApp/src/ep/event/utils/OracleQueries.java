package ep.event.utils;

public class OracleQueries {
	
	public final static String GETALLUSERS = "SELECT * FROM USERS";	
	public final static String GETUSERBYID ="SELECT * FROM USERS "
			+ "where ID = ?";
	
	public final static String GETUSERBYSLUG ="SELECT * FROM USERS "
			+ "where SLUG = ?";
	
	public final static String GETUSERBYEMAIL = "SELECT * FROM USERS "
			+ "WHERE EMAIL = ?";
	
	public final static String SAVEUSER = "INSERT INTO USERS "
			+ "(SLUG, FULL_NAME, EMAIL, PASSWORD, PHONE, ADDRESS, DOB, COUNTRY, STATE, CITY, IMAGE, USER_ROLE, DATE_CREATED, DATE_MODIFIED) "
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public final static String UPDATEUSER = "UPDATE USERS SET "
			+ "SLUG = ?, FULL_NAME = ?, EMAIL = ?, PHONE = ?, ADDRESS = ?, DOB = ?, COUNTRY = ?, STATE = ?, CITY = ?, IMAGE = ?, DATE_MODIFIED = ? "
			+ "WHERE ID = ?";
	
	public final static String UPDATEUSERPASSWORD = "UPDATE USERS SET "
			+ "PASSWORD = ?, DATE_MODIFIED = ? "
			+ "WHERE ID = ?";
	
	public final static String DELETEUSER = "DELETE FROM USERS "
			+ "WHERE ID = ?";
	
	public final static String GETALLEVENTS ="SELECT EVENTS.ID, EVENTS.SLUG, EVENTS.USER_ID, USERS.FULL_NAME, USERS.EMAIL, USERS.PHONE, USERS.USER_ROLE, EVENTS.TITLE, "
			+ "EVENTS.DESCRIPTION, EVENTS.ADDRESS, EVENTS.COUNTRY, EVENTS.STATE, EVENTS.CITY, EVENTS.START_DATE, EVENTS.END_DATE, EVENTS.IMAGE, "
			+ "EVENTS.FEATURE_EVENT, EVENTS.DATE_CREATED, EVENTS.DATE_MODIFIED FROM EVENTS "
			+ "INNER JOIN USERS ON USERS.ID = EVENTS.USER_ID";
	
	public final static String GETEVENTBYID ="SELECT * FROM EVENTS "
			+ "where id = ?";
	
	public final static String GETEVENTBYSLUG ="SELECT * FROM EVENTS "
			+ "where slug = ?";
	
	public final static String GETEVENTSBYUSER ="SELECT * FROM EVENTS "
			+ "where user_id = ?";
	
	public final static String SAVEEVENT = "INSERT INTO EVENTS "
			+ "(SLUG, USER_ID, TITLE, DESCRIPTION, ADDRESS, COUNTRY, STATE, CITY, START_DATE, END_DATE, IMAGE, FEATURE_EVENT, DATE_CREATED, DATE_MODIFIED) "
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public final static String UPDATEEVENT = "UPDATE EVENTS SET "
			+ "SLUG = ?, TITLE = ?, DESCRIPTION = ?, ADDRESS = ?, COUNTRY = ?, STATE = ?, CITY = ?, START_DATE = ?, END_DATE = ?, IMAGE = ?, FEATURE_EVENT = ?, DATE_MODIFIED = ? "
			+ "WHERE EVENTS.ID = ?";
	
	public final static String DELETEEVENT = "DELETE FROM EVENTS "
			+ "WHERE EVENTS.ID = ?";
	
	public final static String GETALLEVENTGALLERIES = "SELECT * FROM EVENT_GALLERIES";
	public final static String GETGALLERYBYID ="SELECT * FROM EVENT_GALLERIES "
			+ "where id = ?";
	
	public final static String GETGALLERYBYSLUG ="SELECT * FROM EVENT_GALLERIES "
			+ "where slug = ?";
	
	public final static String GETGALLERYBYEVENT ="SELECT * FROM EVENT_GALLERIES "
			+ "where event_id = ?";
	
	public final static String SAVEGALLERY = "INSERT INTO EVENT_GALLERIES "
			+ "(SLUG, EVENT_ID, TITLE, DESCRIPTION, DATE_CREATED, DATE_MODIFIED) "
			+ "VALUES (?,?,?,?,?,?)";
	
	public final static String UPDATEGALLERY = "UPDATE EVENT_GALLERIES SET "
			+ "SLUG = ?, TITLE = ?, DESCRIPTION = ?, DATE_MODIFIED = ? "
			+ "WHERE ID = ?";
	
	public final static String DELETEGALLERY = "DELETE FROM EVENT_GALLERIES "
			+ "WHERE ID = ?";
	
	public final static String GETALLEVENTIMAGES = "SELECT * FROM EVENT_IMAGES";
	
	public final static String GETIMAGEBYID ="SELECT * FROM EVENT_IMAGES "
			+ "where id = ?";
	
	public final static String GETIMAGEBYSLUG ="SELECT * FROM EVENT_IMAGES "
			+ "where slug = ?";
	
	public final static String GETIMAGEBYGALLERY ="SELECT * FROM EVENT_IMAGES "
			+ "where event_gallery_id = ?";
	
	public final static String SAVEIMAGE = "INSERT INTO EVENT_IMAGES "
			+ "(SLUG, EVENT_GALLERY_ID, TITLE, IMAGE, DATE_CREATED, DATE_MODIFIED) "
			+ "VALUES (?,?,?,?,?,?)";
	
	public final static String UPDATEIMAGE = "UPDATE EVENT_IMAGES SET "
			+ "SLUG = ?, TITLE = ?, IMAGE = ?, DATE_MODIFIED = ? "
			+ "WHERE ID = ?";
	
	public final static String DELETEIMAGE = "DELETE FROM EVENT_IMAGES "
			+ "WHERE ID = ?";
	
	public final static String GETALLEVENTWISHLISTS = "SELECT * FROM EVENT_WISHLIST";
	
	public final static String GETWISHLISTBYID ="SELECT * FROM EVENT_WISHLIST "
			+ "where ID = ?";
	
	public final static String GETWISHLISTBYSLUG ="SELECT * FROM EVENT_WISHLIST "
			+ "where SLUG = ?";
	
	public final static String GETWISHLISTBYEVENT ="SELECT * FROM EVENT_WISHLIST "
			+ "where EVENT_ID = ?";
	
	public final static String SAVEWISHLIST = "INSERT INTO EVENT_WISHLIST "
			+ "(SLUG, EVENT_ID, TITLE, DESCRIPTION, IMAGE, DATE_CREATED, DATE_MODIFIED) "
			+ "VALUES (?,?,?,?,?,?,?)";
	
	public final static String UPDATEWISHLIST = "UPDATE EVENT_WISHLIST SET "
			+ "SLUG = ?, TITLE = ?, DESCRIPTION = ?, IMAGE = ?, DATE_MODIFIED = ? "
			+ "WHERE ID = ?";
	
	public final static String DELETEWISHLIST = "DELETE FROM EVENT_WISHLIST "
			+ "WHERE ID = ?";
	
	public final static String GETALLEVENTBANNERS = "SELECT * FROM EVENT_BANNERS";
	
	public final static String GETEVENTBANNERBYID ="SELECT * FROM EVENT_BANNERS "
			+ "where ID = ?";
	
	public final static String GETEVENTBANNERBYSLUG ="SELECT * FROM EVENT_BANNERS "
			+ "where SLUG = ?";
	
	public final static String GETBANNERSBYEVENT ="SELECT * FROM EVENT_BANNERS "
			+ "where EVENT_ID = ?";
	
	public final static String SAVEEVENTBANNER = "INSERT INTO EVENT_BANNERS "
			+ "(SLUG, EVENT_ID, TITLE, DESCRIPTION, IMAGE, DATE_CREATED, DATE_MODIFIED) "
			+ "VALUES (?,?,?,?,?,?,?)";
	
	public final static String UPDATEEVENTBANNER = "UPDATE EVENT_BANNERS SET "
			+ "SLUG = ?, TITLE = ?, DESCRIPTION = ?, IMAGE = ?, DATE_MODIFIED = ? "
			+ "WHERE ID = ?";
	
	public final static String DELETEEVENTBANNER = "DELETE FROM EVENT_BANNERS "
			+ "WHERE ID = ?";
	
	public final static String GETALLBANNERS = "SELECT * FROM BANNERS";
	
	public final static String GETBANNERBYID ="SELECT * FROM BANNERS "
			+ "where ID = ?";
	
	public final static String GETBANNERBYSLUG ="SELECT * FROM BANNERS "
			+ "where SLUG = ?";
	
	public final static String GETBANNERSBYUSER ="SELECT * FROM BANNERS "
			+ "where user_id = ?";
	
	public final static String SAVEBANNER = "INSERT INTO BANNERS "
			+ "(SLUG, USER_ID, TITLE, DESCRIPTION, IMAGE, DATE_CREATED, DATE_MODIFIED) "
			+ "VALUES (?,?,?,?,?,?,?)";
	
	public final static String UPDATEBANNER = "UPDATE BANNERS SET "
			+ "SLUG = ?, TITLE = ?, DESCRIPTION = ?, IMAGE = ?, DATE_MODIFIED = ? "
			+ "WHERE ID = ?";
	
	public final static String DELETEBANNER = "DELETE FROM BANNERS "
			+ "WHERE ID = ?";
	
	public final static String GETALLUSERPROFILES = "SELECT * FROM USERS_PROFILES";
	
	public final static String GETUSERPROFILEBYID ="SELECT * FROM USERS_PROFILES "
			+ "where ID = ?";
	
	public final static String GETUSERPROFILEBYSLUG ="SELECT * FROM USERS_PROFILES "
			+ "where SLUG = ?";
	
	public final static String GETPROFILESBYUSER ="SELECT * FROM USERS_PROFILES "
			+ "where user_id = ?";
	
	public final static String SAVEUSERPROFILE = "INSERT INTO USERS_PROFILES "
			+ "(SLUG, USER_ID, TITLE, DESCRIPTION, IMAGE, DATE_CREATED, DATE_MODIFIED) "
			+ "VALUES (?,?,?,?,?,?,?)";
	
	public final static String UPDATEUSERPROFILE = "UPDATE USERS_PROFILES SET "
			+ "SLUG = ?, TITLE = ?, DESCRIPTION = ?, IMAGE = ?, DATE_MODIFIED = ? "
			+ "WHERE ID = ?";
	
	public final static String DELETEUSERPROFILE = "DELETE FROM USERS_PROFILES "
			+ "WHERE ID = ?";
}
