/**
 * 
 */
package ep.event.utils;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * @author Jacob Nartey
 */
public class Slugify {
	private final Pattern NONLATIN = Pattern.compile("[^\\w-]");
	private final Pattern WHITESPACE = Pattern.compile("[\\s]");
	private final Pattern EDGESDHASHES = Pattern.compile("(^-|-$)");

//	public String generateSlug(String text) {
//	    String nowhitespace = WHITESPACE.matcher(text).replaceAll("-");
//	    String normalized = Normalizer.normalize(nowhitespace, Normalizer.Form.NFD);
//	    String slug = NONLATIN.matcher(normalized).replaceAll("");
//	    slug = EDGESDHASHES.matcher(slug).replaceAll("");
//	    return slug.toLowerCase(Locale.ENGLISH);
//	}
	
	public String generateSlug(String text) {
	    return text.replaceAll("[^A-Za-z0-9]+", "-").toLowerCase();
	}
}
