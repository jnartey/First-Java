/**
 * 
 */
package jacob.event.utils;

/**
 * @author Jacob Nartey
 *
 */

public class ImageUploader {
	public String generateDashedString(String string_to_be_dashed) {
		//Using regular expression to replace all symbol with dash
		return string_to_be_dashed.replaceAll("[^A-Za-z0-9]+", "-").toLowerCase();
	}
}
