/**
 * 
 */
package eventprestige.controller;

import java.beans.PropertyEditorSupport;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ep.event.dao.EventDAO;
import ep.event.dao.UserDAO;
import ep.event.model.Event;
import ep.event.model.User;

/**
 * @author Jacob Nartey
 *
 */

@Controller
@RequestMapping("/")
@SessionAttributes("userkey")
public class PagesController {
	
    private UserDAO userDAO;
    private EventDAO eventDAO;
    private HttpSession session;
    
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(true);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
        
        CustomDateEditor dob = new CustomDateEditor(dateFormat, true);
        binder.registerCustomEditor(Date.class, "dob", dob);
        
        SimpleDateFormat dateFormatT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormatT.setLenient(true);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormatT, false));
        
        CustomDateEditor timeStampStart = new CustomDateEditor(dateFormatT, true);
        binder.registerCustomEditor(Timestamp.class, "start_date", timeStampStart);
    }
    
//    @InitBinder
//    public void binder(WebDataBinder binder) {
//    	binder.registerCustomEditor(Timestamp.class,
//        new PropertyEditorSupport() {
//            public void setAsText(String value) {
//                try {
//                    Date parsedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(value);
//                    setValue(new Timestamp(parsedDate.getTime()));
//                } catch (ParseException e) {
//                    setValue(null);
//                }
//            }
//        });
//    }
	
	@ModelAttribute("userkey")
	public User setUpUserForm() {
		return new User();
	}
	
	@RequestMapping(value= {"/", "/index"})
	public ModelAndView index() {
		ModelAndView mav = new ModelAndView("index");
		return mav;
	}
	
	@RequestMapping("/create-account")
	public ModelAndView create_account() {
		ModelAndView mav = new ModelAndView("create_account");
		return mav;
	}
	
	@RequestMapping("/create-event")
	public ModelAndView create_event(@SessionAttribute("userkey") User user, ModelAndView mav) {
		if(user.equals(null)) {
			
			mav.setViewName("redirect:login");
		}else {
			mav.setViewName("create_event");
		}
		
		return mav;
	}
	
	@RequestMapping("/events")
	public ModelAndView events() {
		ModelAndView mav = new ModelAndView("events");
		return mav;
	}
	
	@RequestMapping("/user-events")
	public ModelAndView user_events(@SessionAttribute("userkey") User userkey, ModelAndView mav) {
		
		eventDAO = new EventDAO();
	
		List<Event> events = eventDAO.getEventsByUser(userkey.getUser_id());
		mav.addObject("events", events);
		mav.setViewName("user_events");
		
		return mav;
	}
	
	@RequestMapping("/dashboard")
	public ModelAndView dashboard(@SessionAttribute("userkey") User userkey, ModelAndView mav, HttpServletRequest request) {		
		mav.setViewName("dashboard");
		eventDAO = new EventDAO();
		
		List<Event> events = eventDAO.getEventsByUser(userkey.getUser_id());
		mav.addObject("events", events);
		
		return mav;
	}
	
	@RequestMapping("/account-settings")
	public ModelAndView account_settings(@SessionAttribute("userkey") User userkey, ModelAndView mav) throws SQLException {
		
		userDAO = new UserDAO();
		mav.addObject("user_details", userDAO.getUserByID(userkey.getUser_id()));
		mav.setViewName("account_settings");
		
		return mav;
	}
	
	@RequestMapping(value = "/login", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView process_login(@ModelAttribute User user, ModelAndView mav, HttpServletRequest request, 
			final RedirectAttributes redirectAttributes) throws SQLException {
		
		mav.setViewName("login");
				
		if(user.getEmail() != null) {
			String email = user.getEmail();
			String password = user.getPassword();
			
			User userDetails = null;
			userDAO = new UserDAO();
			boolean isValidated = userDAO.validateLogin(email, password);
			
			if(isValidated) {
				userDetails = userDAO.login(email, password);
				mav.addObject("userkey", userDetails);
				mav.setViewName("dashboard");
			}else if(!isValidated){
				redirectAttributes.addFlashAttribute("message", "<div class=\"callout alert\"><i class=\"fas fa-exclamation-triangle\"></i> Invalid username & password</div>");
		        mav.setViewName("redirect:login");
			}
		}else {
			
		}
				
		return mav;
	}
	
	@RequestMapping(value = "/create-user", method = RequestMethod.POST)
	public ModelAndView process_account(@ModelAttribute User user, ModelAndView mav, 
			final RedirectAttributes redirectAttributes, @ModelAttribute("message") String message) throws SQLException {
		userDAO = new UserDAO();
		Integer UserID = userDAO.registerUser(user);
		if(UserID != null) {
			redirectAttributes.addFlashAttribute("message", "<div class=\"callout success\"><i class=\"far fa-check-circle\"></i> User account for " + user.getFull_name() + " created successfully</div>");
			mav.setViewName("redirect:login");
		}else {
			mav.setViewName("create_account");
		}
		
		return mav;
	}
	
	@RequestMapping(value = "/update-account", method = RequestMethod.POST)
	public ModelAndView update_account(@ModelAttribute User user, @SessionAttribute("userkey") User userkey, 
			HttpServletRequest request, ModelAndView mav) throws SQLException {
		
		userDAO = new UserDAO();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	    java.util.Date parsedDob = null;
	    
		try {
			parsedDob = dateFormat.parse(request.getParameter("dob"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		user.setUser_id(userkey.getUser_id());
		user.setDob(parsedDob);
		
		boolean isUpdated = userDAO.updateUser(user);
		
		if(isUpdated) {
			mav.addObject("message", "<div class=\"callout success\"><i class=\"far fa-check-circle\"></i> " + user.getFull_name() + "'s account updated successfully</div>");
		}else {
			mav.addObject("message", "<div class=\"callout alert\"><i class=\"fas fa-exclamation-triangle\"></i> Error " + user.getFull_name() + "'s account could not be updated</div>");
		}
		
		userDAO = new UserDAO();
		mav.addObject("user_details", userDAO.getUserByID(userkey.getUser_id()));
		mav.setViewName("account_settings");
				
		return mav;
	}
	
	@RequestMapping(value = "/update-password", method = RequestMethod.POST)
	public ModelAndView update_password(@ModelAttribute User user, @SessionAttribute("userkey") User userkey, 
			HttpServletRequest request, ModelAndView mav) throws SQLException {
		
		userDAO = new UserDAO();
		
		user.setUser_id(userkey.getUser_id());
		
		boolean isUpdated = userDAO.updatePasswd(user);
		
		if(isUpdated) {
			mav.addObject("message", "<div class=\"callout success\"><i class=\"far fa-check-circle\"></i> " + userkey.getFull_name() + "'s password updated successfully</div>");
		}else {
			mav.addObject("message", "<div class=\"callout alert\"><i class=\"fas fa-exclamation-triangle\"></i> Error " + userkey.getFull_name() + "'s password could not be updated</div>");
		}
		
		userDAO = new UserDAO();
		mav.addObject("user_details", userDAO.getUserByID(userkey.getUser_id()));
		mav.setViewName("account_settings");
				
		return mav;
	}
	
	@RequestMapping(value = "/create-event", method = RequestMethod.POST)
	public ModelAndView createEvent(@SessionAttribute("userkey") User userkey, /*BindingResult result,*/ 
			HttpServletRequest request, ModelAndView mav, final RedirectAttributes redirectAttributes, @ModelAttribute("message") String message) throws SQLException {
		
		eventDAO = new EventDAO();
		Event event = new Event();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	    java.util.Date parsedStartTimeStamp = null;
	    
		try {
			parsedStartTimeStamp = dateFormat.parse(request.getParameter("start_date"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(parsedStartTimeStamp);
		
        //convert calendar to date
        Timestamp starttimestamp = new Timestamp(cal.getTime().getTime());
		
				
		event.setUser_id(userkey.getUser_id());
		event.setTitle(request.getParameter("title"));
		event.setDescription(request.getParameter("description"));
		event.setAddress(request.getParameter("address"));
		event.setCountry(request.getParameter("country"));
		event.setCity(request.getParameter("city"));
		event.setState(request.getParameter("state"));
		event.setStart_date(starttimestamp);
		event.setEnd_date(starttimestamp);
		event.setImage("non");
		event.setFeature_event(1);
		
		System.out.println(event.toString());
		
		Integer eventID = eventDAO.addEvent(event);
		
		if(!eventID.equals(null)) {
			redirectAttributes.addFlashAttribute("message", "<div class=\"callout success\"><i class=\"far fa-check-circle\"></i> Event " + event.getTitle() + " created successfully</div>");
			mav.setViewName("redirect:user-events");
		}else {
			mav.setViewName("create_event");
		}
		
		return mav;
	}
	
	@RequestMapping(value = "/edit-event/{event_id}", method = {RequestMethod.GET})
	public ModelAndView editEvent(@SessionAttribute("userkey") User userkey, /*BindingResult result,*/ HttpServletRequest request, 
			ModelAndView mav, @PathVariable("event_id")int event_id) throws SQLException {
		
		eventDAO = new EventDAO();
		Event event_details = eventDAO.getEventByID(event_id);
		mav.addObject("event_details", event_details);
		
		mav.setViewName("edit_event");
		
		return mav;
	}
	
	@RequestMapping(value = "/view-event/{event_id}", method = {RequestMethod.GET})
	public ModelAndView viewEvent(@SessionAttribute("userkey") User userkey, /*BindingResult result,*/ HttpServletRequest request, 
			ModelAndView mav, @PathVariable("event_id")int event_id) throws SQLException {
		
		eventDAO = new EventDAO();
		Event event_details = eventDAO.getEventByID(event_id);
		mav.addObject("event_details", event_details);
		
		mav.setViewName("view_event");
		
		return mav;
	}
	
	@RequestMapping(value = "/delete-event/{event_id}", method = {RequestMethod.GET})
	public ModelAndView deleteEvent(@SessionAttribute("userkey") User userkey, /*BindingResult result,*/ HttpServletRequest request, 
			ModelAndView mav, @PathVariable("event_id")int event_id, final RedirectAttributes redirectAttributes) throws SQLException {
		
		eventDAO = new EventDAO();
		Event event_details = eventDAO.getEventByID(event_id);
		boolean isDeleted = eventDAO.deleteEvent(event_id);
		
		if(isDeleted) {
			redirectAttributes.addFlashAttribute("message", "<div class=\"callout success\"><i class=\"far fa-check-circle\"></i> Event " + event_details.getTitle() + " deleted successfully</div>");
		}else {
			redirectAttributes.addFlashAttribute("message", "<div class=\"callout success\"><i class=\"far fa-check-circle\"></i> Event " + event_details.getTitle() + " deleted successfully</div>");
		}
		
		mav.setViewName("redirect:../user-events");
		
		return mav;
	}
	
	@RequestMapping(value = "/update-event", method = {RequestMethod.POST})
	public ModelAndView updateEvent(@SessionAttribute("userkey") User userkey, /*BindingResult result,*/ 
			HttpServletRequest request, ModelAndView mav, final RedirectAttributes redirectAttributes, @ModelAttribute("message") String message) throws SQLException {
		
		eventDAO = new EventDAO();
		Event event = new Event();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	    java.util.Date parsedStartTimeStamp = null;
	    
		try {
			parsedStartTimeStamp = dateFormat.parse(request.getParameter("start_date"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(parsedStartTimeStamp);
		
        //convert calendar to date
        Timestamp starttimestamp = new Timestamp(cal.getTime().getTime());
		
		event.setUser_id(userkey.getUser_id());
		event.setTitle(request.getParameter("title"));
		event.setDescription(request.getParameter("description"));
		event.setAddress(request.getParameter("address"));
		event.setCountry(request.getParameter("country"));
		event.setCity(request.getParameter("city"));
		event.setState(request.getParameter("state"));
		event.setStart_date(starttimestamp);
		event.setEnd_date(starttimestamp);
		event.setFeature_event(1);
		event.setEvent_id(Integer.parseInt(request.getParameter("event_id")));
				
		boolean isUpdated = eventDAO.updateEvent(event);
		
		if(isUpdated) {
			redirectAttributes.addFlashAttribute("message", "<div class=\"callout success\"><i class=\"far fa-check-circle\"></i> Event " + event.getTitle() + " updated successfully</div>");
			mav.setViewName("redirect:user-events");
		}else {
			redirectAttributes.addFlashAttribute("message", "<div class=\"callout alert\"><i class=\"fas fa-exclamation-triangle\"></i> Error Event " + event.getTitle() + " could not be updated</div>");
			mav.setViewName("redirect:edit-event");
		}
		
		return mav;
	}
	
	@RequestMapping("/logout")
    public ModelAndView logout(HttpServletRequest request, SessionStatus status, ModelAndView mav, 
    		final RedirectAttributes redirectAttributes, @ModelAttribute("message") String message) throws IOException, ServletException  {
		
		HttpSession session = request.getSession(false);
        session.removeAttribute("userkey");
        session.invalidate();
        status.setComplete();
        
        redirectAttributes.addFlashAttribute("message", "<div class=\"callout success\"><i class=\"far fa-check-circle\"></i> You have succesfully logged</div>");
		mav.setViewName("redirect:login");		
		return mav;
    }
}
