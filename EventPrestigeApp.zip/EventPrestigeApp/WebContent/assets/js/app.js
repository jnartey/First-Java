$(document).ready(function() {
	$('#slider').layerSlider({
		sliderVersion: '6.0.0',
		type: 'fullwidth',
		responsiveUnder: 1340,
		hideUnder: 0,
		hideOver: 100000,
		skin: 'roundedflat',
		globalBGColor: '#ffffff',
		navStartStop: false,
		skinsPath: 'layerslider/skins/'
	});

	$('#table-1').DataTable();
	$('#table-2').DataTable();
	
	$('[data-toggle="datepicker"]').intimidatetime({
		format: 'yyyy-MM-dd hh:mm:ss',
		previewFormat: 'dd-MM-yyyy hh:mm'
	});
	
	$('[data-toggle="datepicker-i"]').datepicker({
		format: 'mm-dd-yyyy'
	});
	
	$('.delete-confirm').on('click',function(){
		$.confirm({
		    title: 'Delete!',
		    content: 'Are you sure you want to delete ' + $(this).attr("data-title") + '?',
		    buttons: {
		        confirm: function () {
		            return true;
		        },
		        cancel: function () {
		            return false;
		        }
		    }
		});
	});

});

$(document).foundation();